package wintaleur.tickforge.client.command.implementation;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import dev.vellum.mod.client.VellumScreens;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import wintaleur.tickforge.common.command.CommandFactory;
import wintaleur.tickforge.common.command.CommandNames;
import wintaleur.tickforge.server.TickForge;

/** /tf client menu */
public final class HUDCommand {
    private static final String MENU_ID = TickForge.MOD_ID + ":menu.html";

    private HUDCommand() {}

    public static LiteralArgumentBuilder<FabricClientCommandSource> build() {
        return CommandFactory.<FabricClientCommandSource>literal(CommandNames.MENU)
                .executes(HUDCommand::openMenu);
    }

    private static int openMenu(CommandContext<FabricClientCommandSource> context) {
        // Les écrans doivent s'ouvrir sur le thread client, pas sur celui du chat.
        context.getSource().getClient().execute(() -> VellumScreens.open(MENU_ID));

        return Command.SINGLE_SUCCESS;
    }
}
